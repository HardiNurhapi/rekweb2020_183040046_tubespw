<?
require 'functions.php';
session_start();
if (isset($_SESSION['username'])) {
	header("Location: index.php");
	exit;
}
	if(isset($_POST['login'])){
		$username = $_POST['username'];
		$password = $_POST['password'];

		$cek_user = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

		if (mysqli_num_rows($cek_user) > 0) {
			//$_SESSION['username'] = $username;
			//header("Location: index.php");
			//exit;
			$user = mysqli_fetch_assoc($cek_user);
			if (password_verify($password, $user['password'])) {
				// ok, boleh login
				$_SESSION['username'] = $username;
				header("Location: index.php");
			} else {
				//gagal, password salah
				$error = 'Password Salah';
			}
		} else {
			$error = 'Username / Password Belum Terdaftar';
		}
	}

?>
<!DOCTYPE html>
<html>
<head>
<title>Connective Login Form a Responsive Widget Template :: w3layouts</title>
<!-- meta_tags-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="connective login form a Flat Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Meta_tag_Keywords -->
<link href="login1.css" rel="stylesheet" type="text/css" media="all"><!--style_sheet-->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all"><!--font_awesome_icons-->
<!--web_fonts-->
<link href="//fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900&amp;subset=latin-ext" rel="stylesheet">
<!--//web_fonts-->
</head>
<body>
<div class="form">
<h1>Connective Login Form</h1>
	<div class="form-content">
		<form action="#" method="post">
			<div class="form-info">
				<h2>Login</h2>
			</div>
			<div class="email-w3l">
				<span class="i1"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
				<input class="email" type="email" name="email" placeholder="Email" required="">
			</div>
			<div class="pass-w3l">
			<!---728x90--->
			<span class="i2"><i class="fa fa-unlock" aria-hidden="true"></i></span>
				<input class="pass" type="password" name="password" placeholder="Password" required="">
			</div>
			<div class="form-check">
				<div class="left">
					<input type="checkbox" value="Remember me">Remember me
				</div>
				<div class="right">
					<a href="#">Forgot Password?</a>
				</div>
				<div class="clear"></div>
			</div>
			<div class="submit-agileits">
				<input class="login" type="submit" value="login">
			</div>
		</form>
	</div>
</div>
<!---728x90--->
<footer>&copy; 2018 Connective login form. All rights reserved | Design by <a href="#">W3layouts</a></footer>
<!---728x90--->
</body>
</html>