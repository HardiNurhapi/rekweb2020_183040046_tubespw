<?php 
require 'functions.php';

if (isset($_POST["registrasi"])) {
	if (registrasi($_POST) > 0) {
		echo "<script>
				alert('Registrasi Berhasil')
				document.location.href= 'login4.php';
			</script>";
	}
}
?>
<!DOCTYPE HTML>
<html lang="zxx">

<head>
	<title>Appraise Register Form Responsive Widget Template :: w3layouts</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Appraise Register Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs Sign up Web Templates, 
 Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design">
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<!-- Custom Theme files -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="style2.css" rel='stylesheet' type='text/css' />
	<!--fonts-->
	<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i" rel="stylesheet">
	<!--//fonts-->
</head>

<body>
	<!-- login -->
	<h1 class="wthree">Appraise Register Form</h1>
	<div class="login-section-agileits">
		<h3 class="form-head">register online today, Its'free!</h3>
		<form action="#" method="post">
			<div class="w3ls-icon">
				<span class="fa fa-user" aria-hidden="true"></span>
				<input type="text" class="lock" name="username" placeholder="username" required="" />
			</div>
			<div class="w3ls-icon">
				<span class="fa fa-lock" aria-hidden="true"></span>
				<input type="password" class="lock" id="password1" name="password" placeholder="Password" required="" />
			</div>
			<div class="w3ls-icon">
				<span class="fa fa-lock" aria-hidden="true"></span>
				<input type="password" class="lock" id="password2" name="password2" placeholder="Password2" required="" />
			</div>
			<input name="registrasi" type="submit" value="register now">
			<a href="login4.php">kembali</a>
		</form>
	</div>
	<p class="footer-agile">© 2017 Appraise Register Form. All Rights Reserved | Design by
		<a href="http://w3layouts.com/"> W3layouts</a>
	</p>


	<script type="text/javascript">
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}

		function validatePassword() {
			var pass2 = document.getElementById("password2").value;
			var pass1 = document.getElementById("password1").value;
			if (pass1 != pass2)
				document.getElementById("password2").setCustomValidity("Passwords do not Match");
			else
				document.getElementById("password2").setCustomValidity('');
			//empty string means no validation error
		}
	</script>

</body>

</html>