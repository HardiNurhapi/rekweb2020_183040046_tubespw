<?php 
if (!isset($_GET['id'])) {
    header("Location : ../index.php");
    exit;
}
require 'functions.php';
$id = $_GET['id'];

$b = query("SELECT * FROM buku WHERE id = $id")[0];


 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Detail</title>
</head>

    <style>
        
        body { background-color: yellow;

            }
       
        td{
            background-color: ;
            padding : 20px;
        }
        h3{
            text-align : center;
            font-size : 30px;
        }
        .foto img {
            width: 25%;
            height: 20%;
          
        }
        .cc {
            width: 14rem;

        }
    </style> 


<body>
  <center> 

    <h3>Detail Buku</h3>
    <table border="2px">
    <tr>
        
        <th>Cover</th>
        <th>Judul</th>
        <th>Penerbit</th>
        <th>Sinopsis</th>
     
    </tr>
    <tr>
    <td> <img width="120" height="130" src="../asset/img/<?= $b['cover']; ?>"></td>
   
  
    <td><?=  $b['judul']; ?></td>
    
    <td><?=  $b['penerbit']; ?></td>

    <td class="cc"><?=  $b['sinopsis']; ?></td>

    
    </tr>
    </table>
    <form method="post">
        <br>
   <button><a href="halaman_user.php"> Kembali </a></button></center>  
</form>
</body>
</html>