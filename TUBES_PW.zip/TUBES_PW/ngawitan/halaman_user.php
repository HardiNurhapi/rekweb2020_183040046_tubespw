<?php 
require 'functions.php';
$buku = query("SELECT * FROM buku");




?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title> index </title>
    </head>
    <style>
       .container {
        background-color: yellow;
       }
        td{
            padding : 15px;
        }
        h3{
            text-align : center;
            font-size : 50px;
        }
        .foto img {
            width: 25%;
            height: 25%;
          
        }
    </style>
    <body>
        
    </form><br>
        <div class="container">
 
       <br>
           <center><button><a href="login4.php">Login Sebagai Admin</a></button></center><br>    
            <?php foreach ($buku as $b) : ?>
                <div class="content" align="center">
                    <div class="foto">
                        <img width="120" height="130" src="../asset/img/<?= $b['cover']; ?>">
                    </div>
    
                    <p> <?= $b['judul']; ?></p>
                    <p><?= $b['penerbit']; ?></p>
                    <p><?= $b['tahun']; ?></p>

                   <button><a href="user.php?id=<?= $b['id'] ?>">Detail</a></button> 
                 </div>
                 <br>   
           <?php endforeach; ?>
          </div>

<script type="text/javascript" src="user.js"></script>
    </body>
</html>
