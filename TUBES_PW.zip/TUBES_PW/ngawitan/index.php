<?php 
session_start();
if (!isset($_SESSION['username'])) {
	header("Location: login.php");
	exit;
}
require 'functions.php';

$buku = query("SELECT * FROM buku ");

if(isset($_GET['cari'])){
	$keyword = $_GET['keyword'];
	$query_cari = "SELECT * FROM buku WHERE
					judul LIKE '%$keyword%' OR
					penerbit LIKE '%$keyword%'
					";
	$buku = query($query_cari);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Data Buku</title>
</head>
<body bgcolor="yellow">


	<center>
		<a href="logout.php">Logout!</a>

	<h3>Daftar Buku</h3>
	<a href="tambah2.php">Tambah Data Buku</a><br><br>	
	
	<form action="" method="get">
		<input type="text" name="keyword" id="keyword" autocomplete="off">
		<button type="submit" name="cari" id="tombol">Cari</button>	
	</center>
	
	</form><br>
	<div id="container">
		<table border="1" cellpadding="10" cellspacing="0">
			<tr>
				<th>Id.</th>
				<th>Opsi</th>
				<th>Cover</th>
				<th>Judul</th>
				<th>Penerbit</th>
				<th>Sinopsis</th>
				<th>Tahun</th>
			</tr>
			<?php if (empty($buku)) :	?>
				<tr>
					<td colspan="6" align="center">Data Tidak Ditemukan</td>
				</tr>
			<?php endif; ?>

			<?php 
			$i = 1;
			foreach ($buku as $bk) : 
			?>
			<tr>
				<td><?= $i++; ?></td>
				<td>
					<a href="ubah2.php?id=<?= $bk['id']; ?>">ubah</a>  
					<a href="hapus.php?id=<?= $bk['id']; ?>" onclick="return confirm('Yakin Ingin Menghapusnya ?');">hapus</a>
				</td>
				<td><img width="125" height="186" src="../asset/img/<?= $bk['cover']; ?>"></td>
				<td><?= $bk['judul']; ?></td>
				<td><?= $bk['penerbit']; ?></td>
				<td><?= $bk['sinopsis']; ?></td>
				<td><?= $bk['tahun']; ?></td>
				
			</tr>
			<?php endforeach; ?>
		</table>
	</div>

<script type="text/javascript" src="script.js"></script>
</body>
</html>