<?php 
require 'functions.php';

$keyword = $_GET['keyword'];
$query_cari = "SELECT * FROM buku WHERE
				judul LIKE '%$keyword%' OR
				penerbit LIKE '%$keyword%'
				";
$buku = query($query_cari);
 ?>
 		<center>
 			<table border="1" cellpadding="10" cellspacing="0">
			<tr>
				<th>Id.</th>
				<th>Opsi</th>
				<th>Cover</th>
				<th>Judul</th>
				<th>Penerbit</th>
				<th>Sinopsis</th>
				<th>Tahun</th>
			</tr>
			<?php if (empty($buku)) :	?>
				<tr>
					<td colspan="7" align="center">Maaf Data Tidak Ditemukan</td>
				</tr>
 		</center>
 		
			<?php endif; ?>

			<?php 
			$i = 1;
			foreach ($buku as $bk) : 
			?>
			<tr>
				<td><?= $i++; ?></td>
				<td>
					<a href="ubah.php?id=<?= $bk['id']; ?>">ubah</a>  
					<a href="hapus.php?id=<?= $bk['id']; ?>" onclick="return confirm('Yakin Ingin Menghapusnya ?');">hapus</a>
				</td>
				<td><img width="125" height="186" src="../asset/img/<?= $bk['cover']; ?>"></td>
				<td><?= $bk['judul']; ?></td>
				<td><?= $bk['penerbit']; ?></td>
				<td><?= $bk['sinopsis']; ?></td>
				<td><?= $bk['tahun']; ?></td>
				
			</tr>
			<?php endforeach; ?>
		</table>

		