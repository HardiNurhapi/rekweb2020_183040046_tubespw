-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2020 at 07:51 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pw183040046`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `cover` varchar(128) NOT NULL,
  `judul` varchar(64) NOT NULL,
  `penerbit` varchar(128) NOT NULL,
  `sinopsis` varchar(1000) NOT NULL,
  `tahun` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `cover`, `judul`, `penerbit`, `sinopsis`, `tahun`) VALUES
(2, '2.jpg', 'Malin Kundang', 'Dua Media', 'Pada zaman dulu hiduplah sebuah keluarga kecil yg beranggotakan ibu dan anak. Anak tersebut bernama malin yang ingin meraih sukes dengan merantau. ketika dewasa ia pun meminta izin pada ortunya. dengan berat ibunya melepasnya. Setelah Bertahun tahun ibunya mulai merindukannya. Sampai suatu saat malin kembali ke pulau tmpt asalnya dg pakaian mewah layaknya pengusaha kaya dan tidak sengaja bertemu ibunya namun tidak menganggapnya sebagai ibu, sang ibu sedih dan mengutuknya menjadi batu', '2016'),
(3, '3.png', 'Roro Jonggrang', 'CV. Sinar Cemerlang Abadi, Jakarta', 'Pada zaman dahulu kala hiduplah seorang raja berwujud raksasa yang bernama Prabu Baka, dia terkenal rakus dan suka memeras rakyatnya semua takut padanya. ia memilii patih yang setia ber nama patih Gupala. Suatu hari Prabu Baka memimpin ribuan pasukan untuk menyerang kerajaan Penging, dia ingin menguasai kerajaan yang makmur dan subur itu. Perang tak terelakan Prabu Baka mengamuk dan memukul mundur pasukan kerajaan Penging', '2018'),
(4, '4.jpg', 'Jaka Tarub', 'Bintang Indonesia', ' Dalam buku ini menceritakan kisah seorang pemuda yang bernama Jaka Tarub dan seorang bidadari yang bernama Nawang Wulan, hal ini bermula pada saat Jaka Tarub berburu rusa di hutan, ia mendengar canda tawa perempuan di hutan. Kebisingan yang membuatnya begitu ingin tahu, maka Jaka Tarub pun mencari sumber suara tersebut, setelah mencari sumber suara tersebut Jaka Tarub pun melihat ada perempuan-perempuan cantik yang sedang berada di telaga dengan bercanda tawa satu dengan yang lainnya', '2013'),
(5, '5.jpg', 'Kisah Dewi Sri', 'Pustaka Setia', 'Dikisahkan, Batara Guru jatuh cinta pada seorang wanita bernama Ken Tisnawati. Namun Ken Tisnawati mengajukan syarat yang cukup berat. Karena itu Batara Guru marah dan selanjutnya mengutus orang suruhannya untuk mengejar Ken Tisnawati ke mana pun dia pergi. Ken Tisnawati pun merasa tidak tenang hidupnya, sehingga akhirnya dia meninggal', '2007'),
(6, '6.jpg', 'Ciung Wanara', 'Kharisma', 'Di desa Geger Sunten, tepian sungai Citanduy, hiduplah sepasang suami istri tua yang biasa memasang bubu keramba perangkap ikan yang terbuat dari bambu di sungai untuk menangkap ikan. Suatu pagi mereka pergi ke sungai untuk mengambil ikan yang terperangkap', '2010'),
(7, '7.jpg', 'Lutung Kasarung', ' Badan Pengembangan dan Pembinaan Bahasa', 'Dalam buku ini penulis menceritakan tentang kehidupan seorang pangeran yang mencari putri idamannya. Pangeran itu ialah Banyak Catra yang merupakan anak dari Prabu Siliwangi yang didesak untuk segera menikah karena ia harus menggantikan kedudukan di takhta Kerajaan Pajajaran', '2017'),
(8, '8.jpg', 'Sangkuriang', 'CV Pustaka Setia', 'Cerita ini bermula dari seorang anak bernama Sangkuriang yang diusir oleh ibunya, Dayang Sumbi, karena telah membunuh anjing kesayangan ibunya yang ternyata jelmaan dari ayah Sangkuriang, Sona Anggara. Setelah belasan tahun pergi berkelana dan mencari ilmu bela diri, Sangkuriang tak sengaja kembali ke desanya dan bertemu dengan ibunya. Namun, keduanya tidak saling kenal. Karena kecantikan Dayang Sumbi, sangkuriang jatuh cinta kemudian melamar ibunya sendiri', '2002'),
(9, '9.jpg', 'Legenda Danau Toba', ' Aryasatya Ikranegara', ' Zaman dahulu tepatnya di Sumatera Utara hiduplah seorang laki-laki bernama Toba. Pekerjaannya setiap hari adalah berkebun, namun dia juga hoby dengan memancing. Setiap hari selepasnya dari berkebun dia selalu memancing disungai. Suatu hari ketika ia memancing di sungai ia tak mendapatkan seekor ikanpun, karna sudah lama ia tidak mendapatkan ikan ia pun segera pulang kerumah, tetapi tiba-tiba pancing nya di tarik oleh ikan', '2006'),
(10, '10.jpg', 'Timun Mas', 'Lingkar Media', 'Dahulu kala ada seorang janda bernama Mbok Rondo, ia tidak mempunyai anak. Kemudian setelah ia berdoa, ia berjalan dihutan dan berjumpa raksasa dan diberi biji timun emas. Raksasa akan mengabulkan doa Mbok Rondo agar mempunyai anak tetapi ia harus memberikannya lagi kepada raksasa apabila anak tersebut sudah remaja', '2007'),
(33, '1.jpg', 'Si Kabayan', 'Badan Pengembangan dan Pembinaan Bahasa', 'Buku cerita rakyat ini berasal dari Jawa Barat. â€œSi Kabayanâ€ yang dalam mitosnya terkenal sebagai manusia pemalas, sesungguhnya memiliki daya pikir yang luar biasa cerdiknya sehingga orang lain tidak dapat menandingi kecerdikannya.', '2016'),
(34, '12.jpg', 'Si Kancil', 'Niaga Swadaya', 'Pada suatu hari Kancil sedang berjalan-jalan di hutan. Tiba-tiba perutnya terasa lapar. Lalu ia melihat ada banyak buah segar yang ada di seberang sungai deras. Kancil pun bingung, bagaimana caranya ia dapat melewati sungai untuk mendapatkan makanan.  Akhirnya, Kancil menemukan ide cemerlang untuk dapat menyeberangi sungai. Lalu Kancil pun memanggil seekor buaya yang tinggal di dalam sungai.', '2010'),
(35, '13.jpg', 'Dongeng Binatang Legendaris', 'Nuansa Aulia', 'Buku Dongeng Binatang Legendaris ini mengisahkan berbagai cerita binatang (fabel) yang menjadi tokoh dalam cerita. Dan mereka juga bisa berwatak baik maupun jahat. Buku ini juga kaya akan pendidikan karakter. Kita juga akan temukan cerita yang mengandung pesan moral, seperti pentingnya berbuat baik dengan sesama dan menjauhi sifat-sifat buruk supaya tidak mendapat nasib yang malang.', '2007');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$EWJNJKDDRWGgClRtJQ5xte99r0sMJ8YcuIa5WzdVNyowKlqZtfn8m'),
(2, 'user', '$2y$10$WoO9Qtc0tg/nVFIiKspJYOxR1XYVfV1GKi8ULqt7IDkMPD.Xeqm7W'),
(3, 'adut', '$2y$10$N.whBzMeO98N9FgTMX3B4enw6RNGJSLJLLOYtPbhBEDqe4h5T1krG'),
(4, 'anas', '$2y$10$MytUJ3xn0GQlPSApfYXrUODETTA8eMhsk67gWlp8vXKfa.QtTKIl.'),
(5, 'pw', '$2y$10$/UUGeIcs8dpWOkpL22UYnOfXzdlUCiQ5vB2FFQQdiajdt7ckYk0SG'),
(6, 'ade', '$2y$10$i6b9tDr2WDdzt6C.O5BivuxfflhLCVoRyhjMc3hbvA7ABMn5aThoy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
